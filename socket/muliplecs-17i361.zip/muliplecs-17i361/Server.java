import java.net.*;
import java.io.*;
import java.util.*;
public class Server 
{
  public static void main(String[] args) throws Exception 
  {
    try
    {
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter port number: ");
      int PORT = sc.nextInt();
      ServerSocket server=new ServerSocket(PORT);
      int clientCount=0;
      System.out.println("Server Started at port number " + PORT);
      while(true) 
      {
        clientCount++;
        Socket serverClient=server.accept(); 
        System.out.println("Client No:" + clientCount + " started!");
        ServerClientThread sct = new ServerClientThread(serverClient,clientCount);
        sct.start();
      }
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }
}
