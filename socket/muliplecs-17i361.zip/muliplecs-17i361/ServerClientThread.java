import java.net.*;
import java.io.*;
import java.util.*;
class ServerClientThread extends Thread 
{
    Socket serverClient;
    int clientNo;
    int factorial;
    ServerClientThread(Socket inSocket,int counter)
    {
      serverClient = inSocket;
      clientNo=counter;
    }
    public void run()
    {
      try
      {
        DataInputStream inStream = new DataInputStream(serverClient.getInputStream());
        DataOutputStream outStream = new DataOutputStream(serverClient.getOutputStream());
        String clientMessage="", serverMessage="";
        while(!clientMessage.equals("bye")) {
          clientMessage=inStream.readUTF();
          System.out.println("From Client: " +clientNo+ ": Message is :"+ clientMessage);
          System.out.println("Enter a text to respond");
          Scanner sc = new Scanner(System.in);
          String message = sc.next();
          serverMessage="From Server to Client: " + clientNo + " " + message;
          outStream.writeUTF(serverMessage);
          outStream.flush();
        }
        inStream.close();
        outStream.close();
        serverClient.close();
      }
      catch(Exception ex)
      {
        System.out.println(ex);
      }
      finally
      {
        System.out.println("Client -" + clientNo + " exit!! ");
      }
    }
  }